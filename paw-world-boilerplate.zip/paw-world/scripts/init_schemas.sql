-- Run once on DB init (Docker mounts this into initdb.d)
-- Creates one schema per service group, matching __table_args__ in the models.

CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS social;
CREATE SCHEMA IF NOT EXISTS cats;
CREATE SCHEMA IF NOT EXISTS healthcare;
CREATE SCHEMA IF NOT EXISTS hotels;
CREATE SCHEMA IF NOT EXISTS marketplace;
CREATE SCHEMA IF NOT EXISTS breeding;
CREATE SCHEMA IF NOT EXISTS rescue;
CREATE SCHEMA IF NOT EXISTS commerce;    -- reviews + reports
CREATE SCHEMA IF NOT EXISTS payments;
CREATE SCHEMA IF NOT EXISTS notifications;
