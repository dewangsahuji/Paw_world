import asyncio
from logging.config import fileConfig

from sqlalchemy import pool, text
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context

# ── Pull in all models so autogenerate can see every table ───────────
from app.models import Base  # noqa: F401 (side-effect: registers all mappers)
from app.config import settings

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Override URL from pydantic settings (not the ini file)
config.set_main_option("sqlalchemy.url", settings.POSTGRES_URL)

target_metadata = Base.metadata

# All schemas we use — Alembic needs to include them in autogenerate
INCLUDE_SCHEMAS = {
    "auth", "social", "cats", "healthcare",
    "hotels", "marketplace", "breeding",
    "rescue", "commerce", "payments", "notifications",
}


def include_object(object, name, type_, reflected, compare_to):
    """Filter so autogenerate only touches our schemas, not system tables."""
    if type_ == "table":
        return object.schema in INCLUDE_SCHEMAS
    return True


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_schemas=True,
        include_object=include_object,
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        include_schemas=True,
        include_object=include_object,
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        # Ensure all schemas exist before running migrations
        for schema in INCLUDE_SCHEMAS:
            await connection.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema}"))
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
