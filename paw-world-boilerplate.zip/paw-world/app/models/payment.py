import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Enum as SAEnum, ForeignKey, Numeric, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, UUIDMixin


class PaymentStatus(str, enum.Enum):
    PENDING  = "pending"
    SUCCEEDED = "succeeded"
    FAILED   = "failed"
    REFUNDED = "refunded"


class Payment(Base, UUIDMixin):
    __tablename__ = "payments"
    __table_args__ = {"schema": "payments"}

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("social.users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    # nullable FKs: pays for either an order or a booking
    order_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("marketplace.orders.id", ondelete="SET NULL"), nullable=True
    )
    booking_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hotels.bookings.id", ondelete="SET NULL"), nullable=True
    )
    amount: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="INR")
    status: Mapped[PaymentStatus] = mapped_column(
        SAEnum(PaymentStatus, name="payment_status", schema="payments"),
        nullable=False,
        default=PaymentStatus.PENDING,
    )
    provider_ref: Mapped[str | None] = mapped_column(String(255), nullable=True)   # Razorpay / Stripe txn ID
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class Refund(Base, UUIDMixin):
    __tablename__ = "refunds"
    __table_args__ = {"schema": "payments"}

    payment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("payments.payments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    amount: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class PaymentMethod(Base, UUIDMixin):
    __tablename__ = "payment_methods"
    __table_args__ = {"schema": "payments"}

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("social.users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    provider_token: Mapped[str] = mapped_column(String(255), nullable=False)   # tokenised — never raw card
    brand: Mapped[str | None] = mapped_column(String(20), nullable=True)       # visa / mastercard / upi
    last4: Mapped[str | None] = mapped_column(String(4), nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
