"""
Import every model here so Alembic's autogenerate can see all tables
regardless of which module is imported in a migration script.
"""

from app.models.base import Base  # noqa: F401 — re-exported for alembic env.py
from app.models.auth import UserAuth, RefreshToken, PasswordResetToken  # noqa: F401
from app.models.user import User, Profile, Follow, Block  # noqa: F401
from app.models.post import Post, Like, Comment, Hashtag, PostHashtag, Bookmark, StoryLog  # noqa: F401
from app.models.cat import Cat, CatPhoto  # noqa: F401
from app.models.hotel import Hotel, HotelAvailability, Booking  # noqa: F401
from app.models.healthcare import Vet, Appointment, HealthRecord, Vaccination  # noqa: F401
from app.models.marketplace import Product, Order, OrderItem  # noqa: F401
from app.models.breeding import BreedingProfile, BreedingMatch  # noqa: F401
from app.models.rescue import RescueOrganization, RescueListing, RescueApplication, RescueDonation  # noqa: F401
from app.models.review import Review, Report  # noqa: F401
from app.models.payment import Payment, Refund, PaymentMethod  # noqa: F401
from app.models.notification import NotificationPreference, Device  # noqa: F401

__all__ = ["Base"]
