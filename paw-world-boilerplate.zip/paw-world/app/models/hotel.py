import enum
import uuid
from datetime import date, datetime

from sqlalchemy import (
    CheckConstraint, Date, DateTime, Enum as SAEnum, ForeignKey,
    Integer, Numeric, String, Text,
)
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, UUIDMixin


class BookingStatus(str, enum.Enum):
    PENDING   = "pending"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


class Hotel(Base, UUIDMixin):
    __tablename__ = "hotels"
    __table_args__ = {"schema": "hotels"}

    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("social.users.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    area: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    pet_type: Mapped[str] = mapped_column(String(50), nullable=False, default="cat")
    price_per_night: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    rating_avg: Mapped[float | None] = mapped_column(Numeric(3, 2), nullable=True)
    amenities: Mapped[list[str]] = mapped_column(ARRAY(String), nullable=False, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class HotelAvailability(Base, UUIDMixin):
    __tablename__ = "hotel_availability"
    __table_args__ = {"schema": "hotels"}

    hotel_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hotels.hotels.id", ondelete="CASCADE"), nullable=False, index=True
    )
    date: Mapped[date] = mapped_column(Date, nullable=False)
    available_slots: Mapped[int] = mapped_column(Integer, nullable=False, default=0)


class Booking(Base, UUIDMixin):
    __tablename__ = "bookings"
    __table_args__ = (
        # Prevent double-booking: EXCLUDE constraint added via migration (gist extension)
        CheckConstraint("check_out > check_in", name="ck_booking_dates"),
        {"schema": "hotels"},
    )

    hotel_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hotels.hotels.id", ondelete="CASCADE"), nullable=False, index=True
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("social.users.id", ondelete="CASCADE"), nullable=False
    )
    cat_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("cats.cats.id", ondelete="SET NULL"), nullable=True
    )
    check_in: Mapped[date] = mapped_column(Date, nullable=False)
    check_out: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[BookingStatus] = mapped_column(
        SAEnum(BookingStatus, name="booking_status", schema="hotels"),
        nullable=False,
        default=BookingStatus.PENDING,
    )
    total_price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
