import enum
import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, Enum as SAEnum, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, UUIDMixin


class AppointmentStatus(str, enum.Enum):
    PENDING   = "pending"
    CONFIRMED = "confirmed"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class Vet(Base, UUIDMixin):
    __tablename__ = "vets"
    __table_args__ = {"schema": "healthcare"}

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    area: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    specialty: Mapped[str] = mapped_column(String(100), nullable=False)
    pet_type: Mapped[str] = mapped_column(String(50), nullable=False, default="cat")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class Appointment(Base, UUIDMixin):
    __tablename__ = "appointments"
    __table_args__ = {"schema": "healthcare"}

    cat_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("cats.cats.id", ondelete="CASCADE"), nullable=False, index=True
    )
    vet_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("healthcare.vets.id", ondelete="CASCADE"), nullable=False
    )
    scheduled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status: Mapped[AppointmentStatus] = mapped_column(
        SAEnum(AppointmentStatus, name="appointment_status", schema="healthcare"),
        nullable=False,
        default=AppointmentStatus.PENDING,
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class HealthRecord(Base, UUIDMixin):
    __tablename__ = "health_records"
    __table_args__ = {"schema": "healthcare"}

    cat_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("cats.cats.id", ondelete="CASCADE"), nullable=False, index=True
    )
    vet_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("healthcare.vets.id", ondelete="SET NULL"), nullable=True
    )
    diagnosis: Mapped[str | None] = mapped_column(Text, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class Vaccination(Base, UUIDMixin):
    __tablename__ = "vaccinations"
    __table_args__ = {"schema": "healthcare"}

    cat_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("cats.cats.id", ondelete="CASCADE"), nullable=False, index=True
    )
    vaccine_name: Mapped[str] = mapped_column(String(255), nullable=False)
    administered_at: Mapped[date] = mapped_column(Date, nullable=False)
    next_due_at: Mapped[date | None] = mapped_column(Date, nullable=True)
