import enum
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, UUIDMixin


class MatchStatus(str, enum.Enum):
    PENDING  = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"


class BreedingProfile(Base, UUIDMixin):
    __tablename__ = "breeding_profiles"
    __table_args__ = {"schema": "breeding"}

    cat_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("cats.cats.id", ondelete="CASCADE"), nullable=False
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("social.users.id", ondelete="CASCADE"), nullable=False
    )
    area: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    pet_type: Mapped[str] = mapped_column(String(50), nullable=False, default="cat")
    breed: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class BreedingMatch(Base, UUIDMixin):
    __tablename__ = "breeding_matches"
    __table_args__ = {"schema": "breeding"}

    requester_profile_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("breeding.breeding_profiles.id", ondelete="CASCADE"),
        nullable=False,
    )
    target_profile_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("breeding.breeding_profiles.id", ondelete="CASCADE"),
        nullable=False,
    )
    status: Mapped[MatchStatus] = mapped_column(
        SAEnum(MatchStatus, name="match_status", schema="breeding"),
        nullable=False,
        default=MatchStatus.PENDING,
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
