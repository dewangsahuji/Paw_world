from fastapi import APIRouter

router = APIRouter(prefix="/api/hashtags", tags=["Hashtags"])

# ── Endpoints ───────────────────────────────────────────────────────
# GET /{tag}
# GET /{tag}/posts

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #10
