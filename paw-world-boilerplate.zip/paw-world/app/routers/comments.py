from fastapi import APIRouter

router = APIRouter(prefix="/api/posts", tags=["Comments"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /{post_id}/comments
# GET /{post_id}/comments
# PUT /comments/{comment_id}
# DELETE /comments/{comment_id}

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #6
