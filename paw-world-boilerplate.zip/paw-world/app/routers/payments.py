from fastapi import APIRouter

router = APIRouter(prefix="/payments", tags=["Payments"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /checkout
# GET /{payment_id}
# POST /{payment_id}/refund
# GET /payment-methods
# POST /payment-methods

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #21
