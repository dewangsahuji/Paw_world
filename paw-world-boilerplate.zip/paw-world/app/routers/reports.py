from fastapi import APIRouter

router = APIRouter(prefix="/reports", tags=["Reports"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /
# GET /
# PUT /{report_id}/status

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #19
