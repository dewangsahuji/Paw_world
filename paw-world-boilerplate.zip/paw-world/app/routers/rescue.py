from fastapi import APIRouter

router = APIRouter(prefix="/rescue", tags=["Rescue"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /organizations
# GET /organizations
# POST /listings
# GET /listings
# POST /applications
# GET /applications
# POST /donations

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #17
