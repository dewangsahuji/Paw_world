from fastapi import APIRouter

router = APIRouter(prefix="/hotels", tags=["Hotels"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /
# GET /
# GET /{hotel_id}
# PUT /{hotel_id}
# DELETE /{hotel_id}
# GET /{hotel_id}/availability
# POST /bookings
# GET /bookings
# GET /bookings/{booking_id}
# POST /bookings/{booking_id}/cancel

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #13
