from fastapi import APIRouter

router = APIRouter(prefix="/api/search", tags=["Search"])

# ── Endpoints ───────────────────────────────────────────────────────
# GET /
# GET /users
# GET /posts
# GET /hotels
# GET /products
# GET /vets
# GET /rescue-listings
# GET /breeders
# GET /filters

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #9
