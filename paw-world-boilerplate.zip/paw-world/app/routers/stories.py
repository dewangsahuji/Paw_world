from fastapi import APIRouter

router = APIRouter(prefix="/api/stories", tags=["Stories"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /
# GET /
# GET /{story_id}
# DELETE /{story_id}
# POST /{story_id}/view

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #8
