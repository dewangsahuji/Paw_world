from fastapi import APIRouter

router = APIRouter(prefix="/api/profile", tags=["Profile"])

# ── Endpoints ───────────────────────────────────────────────────────
# GET /
# PUT /
# POST /avatar
# POST /banner

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #3
