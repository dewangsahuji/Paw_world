from fastapi import APIRouter

router = APIRouter(prefix="/reviews", tags=["Reviews"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /
# GET /
# PUT /{review_id}
# DELETE /{review_id}

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #18
