from fastapi import APIRouter

router = APIRouter(prefix="/api/posts", tags=["Likes"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /{post_id}/like
# DELETE /{post_id}/like
# GET /{post_id}/likes

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #5
