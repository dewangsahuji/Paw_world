from fastapi import APIRouter

router = APIRouter(prefix="/api/posts", tags=["Bookmarks"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /{post_id}/save
# DELETE /{post_id}/save
# GET /saved-posts

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #11
