from fastapi import APIRouter

router = APIRouter(prefix="/notifications", tags=["Notifications"])

# ── Endpoints ───────────────────────────────────────────────────────
# GET /
# POST /read
# GET /preferences
# PUT /preferences
# POST /devices

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #22
