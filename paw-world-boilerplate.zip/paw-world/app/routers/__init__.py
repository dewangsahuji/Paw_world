from fastapi import APIRouter

from app.routers import (
    auth, users, profile,
    posts, likes, comments, feed, stories,
    hashtags, bookmarks,
    search,
    cats, healthcare, breeding,
    hotels, marketplace, rescue,
    reviews, reports,
    messaging, payments, notifications,
)

api_router = APIRouter()

# ── Auth & Users ─────────────────────────────────────────────────────
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(profile.router)

# ── Social ───────────────────────────────────────────────────────────
api_router.include_router(posts.router)
api_router.include_router(likes.router)
api_router.include_router(comments.router)
api_router.include_router(feed.router)
api_router.include_router(stories.router)
api_router.include_router(hashtags.router)
api_router.include_router(bookmarks.router)
api_router.include_router(search.router)

# ── Cats ─────────────────────────────────────────────────────────────
api_router.include_router(cats.router)
api_router.include_router(healthcare.router)
api_router.include_router(breeding.router)

# ── Commerce ─────────────────────────────────────────────────────────
api_router.include_router(hotels.router)
api_router.include_router(marketplace.router)
api_router.include_router(rescue.router)
api_router.include_router(reviews.router)
api_router.include_router(reports.router)

# ── Platform ─────────────────────────────────────────────────────────
api_router.include_router(messaging.router)
api_router.include_router(payments.router)
api_router.include_router(notifications.router)
