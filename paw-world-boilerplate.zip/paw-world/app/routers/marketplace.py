from fastapi import APIRouter

router = APIRouter(prefix="/", tags=["Marketplace"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /products
# GET /products
# GET /products/{product_id}
# PUT /products/{product_id}
# DELETE /products/{product_id}
# GET /cart
# POST /cart
# POST /orders
# GET /orders
# GET /orders/{order_id}

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #15
