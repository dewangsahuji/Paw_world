from fastapi import APIRouter

router = APIRouter(prefix="/", tags=["Healthcare"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /appointments
# GET /appointments
# GET /appointments/{id}
# POST /health-records
# GET /health-records/{cat_id}
# POST /vaccinations
# GET /vaccinations/{cat_id}
# GET /vets

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #14
