from fastapi import APIRouter

router = APIRouter(prefix="/cats", tags=["Cats"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /
# GET /
# GET /{cat_id}
# PUT /{cat_id}
# DELETE /{cat_id}
# GET /user/{user_id}
# POST /{cat_id}/photos

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #12
