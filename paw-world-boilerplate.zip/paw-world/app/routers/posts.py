from fastapi import APIRouter

router = APIRouter(prefix="/api/posts", tags=["Posts"])

# ── Endpoints ───────────────────────────────────────────────────────
# POST /
# GET /
# GET /{post_id}
# PUT /{post_id}
# DELETE /{post_id}
# GET /user/{user_id}

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #4
