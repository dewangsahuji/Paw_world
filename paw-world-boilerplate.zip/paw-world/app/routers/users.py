from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import func, select

from app.core.dependencies import DB, CurrentUser
from app.models.user import Block, Follow, User
from app.schemas.common import MessageResponse, PaginatedResponse
from app.schemas.user import UserResponse, UserUpdateRequest, UserWithStats

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", response_model=PaginatedResponse[UserResponse])
async def list_users(
    db: DB,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    q: str | None = Query(None, description="Search by username or display_name"),
):
    offset = (page - 1) * page_size
    stmt = select(User).where(User.is_active == True)  # noqa: E712

    if q:
        stmt = stmt.where(
            User.username.ilike(f"%{q}%") | User.display_name.ilike(f"%{q}%")
        )

    total_result = await db.execute(select(func.count()).select_from(stmt.subquery()))
    total = total_result.scalar_one()

    result = await db.execute(stmt.offset(offset).limit(page_size).order_by(User.created_at.desc()))
    users = result.scalars().all()

    return PaginatedResponse(
        items=users,
        total=total,
        page=page,
        page_size=page_size,
        has_next=(offset + page_size) < total,
    )


@router.get("/{user_id}", response_model=UserWithStats)
async def get_user(user_id: UUID, db: DB):
    result = await db.execute(select(User).where(User.id == user_id, User.is_active == True))  # noqa: E712
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    follower_count = await db.scalar(select(func.count()).where(Follow.followed_id == user_id))
    following_count = await db.scalar(select(func.count()).where(Follow.follower_id == user_id))

    return UserWithStats(
        **UserResponse.model_validate(user).model_dump(),
        follower_count=follower_count or 0,
        following_count=following_count or 0,
    )


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(user_id: UUID, body: UserUpdateRequest, db: DB, current_user: CurrentUser):
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="Cannot update another user's account")

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if body.display_name is not None:
        user.display_name = body.display_name
    if body.email is not None:
        user.email = body.email
    user.updated_at = datetime.now(timezone.utc)

    await db.commit()
    await db.refresh(user)
    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(user_id: UUID, db: DB, current_user: CurrentUser):
    if current_user.id != user_id:
        raise HTTPException(status_code=403, detail="Forbidden")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = False
    user.updated_at = datetime.now(timezone.utc)
    await db.commit()


@router.get("/{user_id}/followers", response_model=list[UserResponse])
async def get_followers(user_id: UUID, db: DB):
    stmt = (
        select(User)
        .join(Follow, Follow.follower_id == User.id)
        .where(Follow.followed_id == user_id, User.is_active == True)  # noqa: E712
    )
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{user_id}/following", response_model=list[UserResponse])
async def get_following(user_id: UUID, db: DB):
    stmt = (
        select(User)
        .join(Follow, Follow.followed_id == User.id)
        .where(Follow.follower_id == user_id, User.is_active == True)  # noqa: E712
    )
    result = await db.execute(stmt)
    return result.scalars().all()


@router.post("/{user_id}/follow", status_code=status.HTTP_204_NO_CONTENT)
async def follow_user(user_id: UUID, db: DB, current_user: CurrentUser):
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Cannot follow yourself")

    existing = await db.scalar(
        select(Follow).where(Follow.follower_id == current_user.id, Follow.followed_id == user_id)
    )
    if existing:
        return  # idempotent

    follow = Follow(
        follower_id=current_user.id,
        followed_id=user_id,
        created_at=datetime.now(timezone.utc),
    )
    db.add(follow)
    await db.commit()


@router.delete("/{user_id}/follow", status_code=status.HTTP_204_NO_CONTENT)
async def unfollow_user(user_id: UUID, db: DB, current_user: CurrentUser):
    result = await db.execute(
        select(Follow).where(Follow.follower_id == current_user.id, Follow.followed_id == user_id)
    )
    follow = result.scalar_one_or_none()
    if follow:
        await db.delete(follow)
        await db.commit()


@router.post("/{user_id}/block", status_code=status.HTTP_204_NO_CONTENT)
async def block_user(user_id: UUID, db: DB, current_user: CurrentUser):
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Cannot block yourself")
    existing = await db.scalar(
        select(Block).where(Block.blocker_id == current_user.id, Block.blocked_id == user_id)
    )
    if not existing:
        db.add(Block(blocker_id=current_user.id, blocked_id=user_id, created_at=datetime.now(timezone.utc)))
        await db.commit()


@router.delete("/{user_id}/block", status_code=status.HTTP_204_NO_CONTENT)
async def unblock_user(user_id: UUID, db: DB, current_user: CurrentUser):
    result = await db.execute(
        select(Block).where(Block.blocker_id == current_user.id, Block.blocked_id == user_id)
    )
    block = result.scalar_one_or_none()
    if block:
        await db.delete(block)
        await db.commit()


@router.get("/blocked", response_model=list[UserResponse])
async def get_blocked(db: DB, current_user: CurrentUser):
    stmt = (
        select(User)
        .join(Block, Block.blocked_id == User.id)
        .where(Block.blocker_id == current_user.id)
    )
    result = await db.execute(stmt)
    return result.scalars().all()
