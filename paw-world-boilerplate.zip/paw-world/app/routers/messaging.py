from fastapi import APIRouter

router = APIRouter(prefix="/conversations", tags=["Messaging"])

# ── Endpoints ───────────────────────────────────────────────────────
# GET /
# POST /
# GET /{conversation_id}/messages
# POST /{conversation_id}/messages

# TODO: implement each route below.
# Reference: API Endpoint Reference doc, service #20
