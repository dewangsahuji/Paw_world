from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import security
from app.core.dependencies import get_db, get_redis_dep, CurrentUser
from app.database.redis_client import RedisKeys
from app.models.auth import UserAuth, RefreshToken, PasswordResetToken
from app.models.user import User, Profile
from app.schemas.auth import (
    ForgotPasswordRequest,
    LoginRequest,
    MeResponse,
    RefreshTokenRequest,
    RegisterRequest,
    ResetPasswordRequest,
    TokenResponse,
)
from jose import JWTError
import redis.asyncio as aioredis
import uuid

router = APIRouter(prefix="/api/auth", tags=["Auth"])


@router.post("/register", response_model=MeResponse, status_code=status.HTTP_201_CREATED)
async def register(body: RegisterRequest, db: AsyncSession = Depends(get_db)):
    # Uniqueness checks
    existing_email = await db.execute(select(UserAuth).where(UserAuth.email == body.email))
    if existing_email.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already registered")

    existing_username = await db.execute(select(User).where(User.username == body.username))
    if existing_username.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Username already taken")

    now = datetime.now(timezone.utc)
    shared_id = uuid.uuid4()

    # Auth record
    auth = UserAuth(
        id=shared_id,
        email=body.email,
        password_hash=security.hash_password(body.password),
        created_at=now,
        updated_at=now,
    )
    db.add(auth)

    # User record (same UUID)
    user = User(
        id=shared_id,
        username=body.username,
        display_name=body.display_name,
        email=body.email,
        created_at=now,
        updated_at=now,
    )
    db.add(user)

    # Profile stub
    profile = Profile(user_id=shared_id, updated_at=now)
    db.add(profile)

    await db.commit()
    await db.refresh(user)
    return user


@router.post("/login", response_model=TokenResponse)
async def login(
    body: LoginRequest,
    db: AsyncSession = Depends(get_db),
    redis: aioredis.Redis = Depends(get_redis_dep),
):
    result = await db.execute(select(UserAuth).where(UserAuth.email == body.email))
    auth = result.scalar_one_or_none()
    if not auth or not security.verify_password(body.password, auth.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    access_token, _ = security.create_access_token(str(auth.id))
    refresh_token, refresh_jti = security.create_refresh_token(str(auth.id))

    # Persist refresh token hash
    from app.config import settings
    from datetime import timedelta
    now = datetime.now(timezone.utc)
    rt = RefreshToken(
        user_id=auth.id,
        token_hash=security.hash_password(refresh_token),
        expires_at=now + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        created_at=now,
    )
    db.add(rt)
    await db.commit()

    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    current_user: CurrentUser,
    token: Annotated[str, Depends(security.decode_token)],   # reuse decoded payload below
    redis: aioredis.Redis = Depends(get_redis_dep),
):
    # Adding the access token's JTI to denylist (TTL = remaining lifetime)
    # In practice, decode from the raw Bearer token in the request header.
    # Here we just invalidate by user — a more granular approach tracks jti.
    await redis.setex(
        RedisKeys.JWT_DENYLIST.format(jti="session"),
        60 * 60,  # 1 hour — longer than access token lifetime is sufficient
        "revoked",
    )


@router.post("/refresh-token", response_model=TokenResponse)
async def refresh_token(
    body: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        payload = security.decode_token(body.refresh_token)
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user_id = payload["sub"]
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

    new_access, _ = security.create_access_token(user_id)
    new_refresh, _ = security.create_refresh_token(user_id)
    return TokenResponse(access_token=new_access, refresh_token=new_refresh)


@router.post("/forgot-password", status_code=status.HTTP_204_NO_CONTENT)
async def forgot_password(body: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    # Always return 204 to avoid email enumeration.
    result = await db.execute(select(UserAuth).where(UserAuth.email == body.email))
    auth = result.scalar_one_or_none()
    if auth:
        # TODO: generate token, store hash, send email via your mail service
        pass


@router.post("/reset-password", status_code=status.HTTP_204_NO_CONTENT)
async def reset_password(body: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    # TODO: look up PasswordResetToken by token_hash, validate expiry, update password
    raise HTTPException(status_code=501, detail="Not implemented yet")


@router.get("/me", response_model=MeResponse)
async def me(current_user: CurrentUser):
    return current_user
