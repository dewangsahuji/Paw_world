from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from app.config import settings

_client: AsyncIOMotorClient | None = None


def get_mongo_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.MONGODB_URL)
    return _client


def get_mongo_db() -> AsyncIOMotorDatabase:
    return get_mongo_client()[settings.MONGODB_DB]


async def close_mongo() -> None:
    global _client
    if _client is not None:
        _client.close()
        _client = None


# ── Collection helpers ───────────────────────────────────────────────
# Call these from routers/services — keeps collection names in one place.

def conversations_col():
    return get_mongo_db()["conversations"]

def messages_col():
    return get_mongo_db()["messages"]

def notifications_col():
    return get_mongo_db()["notifications"]
