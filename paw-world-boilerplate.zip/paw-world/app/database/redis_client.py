import json
from typing import Any
import redis.asyncio as aioredis
from app.config import settings

_pool: aioredis.ConnectionPool | None = None


def get_redis_pool() -> aioredis.ConnectionPool:
    global _pool
    if _pool is None:
        _pool = aioredis.ConnectionPool.from_url(
            settings.REDIS_URL,
            max_connections=50,
            decode_responses=True,
        )
    return _pool


def get_redis() -> aioredis.Redis:
    return aioredis.Redis(connection_pool=get_redis_pool())


async def close_redis() -> None:
    global _pool
    if _pool is not None:
        await _pool.aclose()
        _pool = None


# ── Typed key helpers ────────────────────────────────────────────────
# Centralises key naming so nothing is hardcoded in router files.

class RedisKeys:
    # Posts cache
    POST           = "post:{post_id}"
    USER_RECENT    = "user:{user_id}:recent_posts"

    # Likes
    LIKE_COUNT     = "post:{post_id}:like_count"
    LIKED_BY       = "post:{post_id}:liked_by"

    # Feed
    FEED           = "feed:{user_id}"
    FEED_TRENDING  = "feed:trending"
    FEED_EXPLORE   = "feed:explore:{user_id}"

    # Stories (TTL = 86400)
    STORY          = "story:{story_id}"
    USER_STORIES   = "user:{user_id}:stories"
    STORY_VIEWERS  = "story:{story_id}:viewers"

    # Hashtags trending
    TRENDING_TAGS  = "hashtags:trending"

    # Cart
    CART           = "cart:{user_id}"

    # Auth / JWT denylist
    JWT_DENYLIST   = "auth:denylist:{jti}"

    # Notification unread count
    NOTIF_UNREAD   = "notif:{user_id}:unread_count"


# ── Generic helpers ──────────────────────────────────────────────────

async def set_json(redis: aioredis.Redis, key: str, value: Any, ttl: int | None = None) -> None:
    serialised = json.dumps(value)
    if ttl:
        await redis.setex(key, ttl, serialised)
    else:
        await redis.set(key, serialised)


async def get_json(redis: aioredis.Redis, key: str) -> Any | None:
    raw = await redis.get(key)
    return json.loads(raw) if raw else None
