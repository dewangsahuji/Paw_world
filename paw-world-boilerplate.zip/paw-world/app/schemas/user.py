from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, EmailStr, Field, ConfigDict


# ── User ─────────────────────────────────────────────────────────────

class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    username: str
    display_name: str | None
    email: str
    is_active: bool
    created_at: datetime


class UserUpdateRequest(BaseModel):
    display_name: str | None = Field(None, max_length=100)
    email: EmailStr | None = None


# ── Profile ───────────────────────────────────────────────────────────

class ProfileResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    user_id: UUID
    bio: str | None
    avatar_url: str | None
    banner_url: str | None
    location: str | None
    updated_at: datetime


class ProfileUpdateRequest(BaseModel):
    bio: str | None = Field(None, max_length=500)
    location: str | None = Field(None, max_length=255)


# ── Social stats (follower counts etc.) ───────────────────────────────

class UserWithStats(UserResponse):
    follower_count: int = 0
    following_count: int = 0
