import uuid
from typing import Annotated, AsyncGenerator

import redis.asyncio as aioredis
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import security
from app.database.postgres import AsyncSessionLocal
from app.database.redis_client import get_redis, RedisKeys
from app.models.auth import UserAuth
from app.models.user import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ── PostgreSQL session ───────────────────────────────────────────────

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


DB = Annotated[AsyncSession, Depends(get_db)]


# ── Redis connection ─────────────────────────────────────────────────

async def get_redis_dep() -> aioredis.Redis:
    return get_redis()


Redis = Annotated[aioredis.Redis, Depends(get_redis_dep)]


# ── Current user ─────────────────────────────────────────────────────

async def get_current_user(
    token: Annotated[str, Depends(oauth2_scheme)],
    db: DB,
    redis: Redis,
) -> User:
    credentials_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = security.decode_token(token)
        if payload.get("type") != "access":
            raise credentials_exc
        user_id: str = payload["sub"]
        jti: str = payload["jti"]
    except (JWTError, KeyError):
        raise credentials_exc

    # Check JWT denylist (logout / rotation)
    if await redis.exists(RedisKeys.JWT_DENYLIST.format(jti=jti)):
        raise credentials_exc

    result = await db.execute(select(User).where(User.id == uuid.UUID(user_id)))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise credentials_exc

    return user


CurrentUser = Annotated[User, Depends(get_current_user)]
