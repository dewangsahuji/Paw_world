from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database.mongodb import close_mongo
from app.database.redis_client import close_redis
from app.core.exceptions import register_exception_handlers
from app.routers import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ──────────────────────────────────────────────────────
    # MongoDB indexes (idempotent)
    from app.database.mongodb import messages_col, notifications_col, conversations_col
    await messages_col().create_index([("conversation_id", 1), ("sent_at", -1)])
    await notifications_col().create_index([("user_id", 1), ("created_at", -1)])
    await conversations_col().create_index([("participant_ids", 1)])
    yield
    # ── Shutdown ─────────────────────────────────────────────────────
    await close_mongo()
    await close_redis()


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        docs_url="/docs" if settings.DEBUG else None,
        redoc_url="/redoc" if settings.DEBUG else None,
        lifespan=lifespan,
    )

    # ── CORS ─────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Exception handlers ───────────────────────────────────────────
    register_exception_handlers(app)

    # ── Routes ───────────────────────────────────────────────────────
    app.include_router(api_router)

    @app.get("/health", tags=["Health"])
    async def health():
        return {"status": "ok", "version": settings.APP_VERSION}

    return app


app = create_app()
